spotify <- read.csv("Popular_Spotify_Songs.csv")
spotify
View(spotify)
library(regclass)

streamsnew <- as.numeric(spotify$streams)
#streamsnew <- ifelse(spotify$streams == "CategoryA", 575, NA) #run if there are NA's


View(streamsnew)

associate(streamsnew ~ spotify$artist_count)
associate(streamsnew ~ spotify$artist_count, data = spotify, permutations = 500, seed = 298)

result <- associate(streamsnew ~ spotify$artist_count, data = spotify, permutations = 500, seed = 298, method = "spearman")
summary_result <- summary(result)
summary_result

library(ggplot2)
ggplot(spotify, aes(x = artist_count, y = streamsnew)) +
  geom_point(color = "#0073e6") +
  labs(x = "Artist Count", y = "Streams",
       title = "Association between Artist Count and Streams") +
  theme_minimal() +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"))

model <- lm(streamsnew ~ artist_count, data = spotify)
predictions <- predict(model, spotify)
mse <- mean((spotify$streamsnew - predictions)^2, na.rm = TRUE)
sse <- sum((spotify$streamsnew - predictions)^2, na.rm = TRUE)
rmse <- sqrt(mse)
mse
sse
rmse

spotify <- read.csv("Popular_Spotify_Songs.csv")
spotify$streams[575] <- NA
spotify$streams <- as.numeric(spotify$streams)
spotify$streamsnew <- ifelse(spotify$streams == "CategoryA", 575, spotify$streams)
library(regclass)
#pearsons
result <- associate(streamsnew ~ spotify$in_spotify_playlists, data = spotify, permutations = 500, seed = 298, method = "pearson")

#Scatter Plot 
library(ggplot2)
ggplot(spotify, aes(x = in_spotify_playlists, y = streamsnew)) +
  geom_point(color = "red") +
  labs(x = "In Spotify Playlists", y = "Streams",
       title = "Association between Spotify PLaylist and Streams") +
  theme_minimal() +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"))
#Linear Regression
model <- lm(streamsnew ~ in_spotify_playlists, data = spotify)
summary(model)

#Plot With Regression
plot <- ggplot(spotify, aes(x = in_spotify_playlists, y = streamsnew)) +
  geom_point(color = "red") +
  geom_smooth(method = "lm", se = FALSE, color = "blue") + # Add regression line
  labs(x = "In Spotify Playlists", y = "Streams",
       title = "Association between Spotify Playlist and Streams") +
  theme_minimal() +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14, face = "bold"))
print(plot)

#Association Analysis
  associate(streamsnew~spotify$in_apple_playlists)
associate(streamsnew~spotify$in_apple_playlists, data = spotify, permutations = 500, seed = 298)

#Regression Analysis:
  M <- lm(streamsnew~in_apple_playlists,data=spotify)
plot(streams~in_apple_playlists,data=spotify)
abline(M)
anova(M)
summary(M)
possible_regressions(M)

library(ggplot2)
ggplot(spotify, aes(x = in_apple_playlists, y = streamsnew)) +
  geom_point(color = "green") +
  geom_smooth(method = "lm", se = FALSE) +
  labs(x = "In Apple Playlists", y = "Spotify Streams") +
  theme_minimal()


associate(streamsnew~spotify$in_spotify_charts)
associate(streamsnew ~ spotify$in_spotify_charts, data = spotify, permutations = 500, seed = 298)
cor_matrix(spotify)
plot(streamsnew ~ spotify$in_spotify_charts, pch = 16, col = "green", cex = 0.5, xlab = "In Spotify Charts", ylab = "Streams")
data(spotify)
plot(streamsnew ~ spotify$in_spotify_charts, data = spotify, pch = 16, col = "green", cex = 0.5, xlab = "In Spotify Charts", ylab = "Streams", xlim = c(1, 150))
abline(spotifyreg, col = "blue")
spotifyreg <-lm(spotify$streams~spotify$in_spotify_charts)


possible_regressions(spotifyreg)
anova(spotifyreg)
summary(spotifyreg)

install.packages("shiny")

library(shiny)
library(ggplot2)

spotify <- read.csv("Popular_Spotify_Songs.csv")

spotify$streamsnew <- as.numeric(spotify$streams)

spotify <- na.omit(spotify)
spotify <- spotify[is.finite(spotify$streamsnew) & is.finite(spotify$in_spotify_charts), ]

ui <- fluidPage(
  titlePanel("Spotify Data Analysis"),
  sidebarLayout(
    sidebarPanel(
      actionButton("runRegression", "Run Regression")
    ),
    mainPanel(
      plotOutput("disPlot")
    )
  )
)

server <- function(input, output) {
  
  regressionResults <- reactive({
    req(input$runRegression)
    
    spotifyreg <- lm(streamsnew ~ in_spotify_charts, data = spotify)
    
    ggplot(spotify, aes(x = in_spotify_charts, y = streamsnew)) +
      geom_point(color = 'green', size = 0.5) + 
      geom_smooth(method = "lm", se = FALSE, color = "red") +
      labs(x = "In Spotify Charts", y = "Streams", title = "Scatter Plot of Spotify Streams vs. Charts") +
      xlim(0, 100) 
  })
  
  output$disPlot <- renderPlot({
    print(regressionResults())
  })
}

shinyApp(ui = ui, server = server)

spotify <- read.csv("Popular_Spotify_Songs.csv")
names(spotify)
spotify
View(spotify)
library(regclass)

streamsnew <-as.numeric(spotify$streams)
streamsnew <- ifelse(spotify$streams == "CategoryA", 575, NA)

View(streamsnew)

# performing an association analysis between danceability and streams on Spotify data.

associate<-associate(streamsnew~spotify$danceability_.)
associate_per500<-associate(streamsnew~spotify$danceability_., data = spotify, permutations = 500, seed = 298)
#using ggplot2 for plot 
library(ggplot2)

ggplot(spotify, aes(x = danceability_., y = streamsnew)) +
  geom_point(color ="black", alpha = 0.8, size = 2) + 
  labs(x = "danceability_.", y = "Streams",
       title = "Association between Streams and danceability_. and Streams") +  
  theme_minimal() +  
  theme(
    plot.title = element_text(size = 16, face = "bold"),  
    axis.text = element_text(size = 18),  
    axis.title = element_text(size = 14, face = "bold")  
  )


#2. let make the model of the regression

model<-lm(streamsnew~danceability_.,data =spotify )
model
possible_regressions(model)
summary(model)

# using  the confint() function to compute confidence intervals for the coefficients in the regression mode
confint(model,level = 0.95)

